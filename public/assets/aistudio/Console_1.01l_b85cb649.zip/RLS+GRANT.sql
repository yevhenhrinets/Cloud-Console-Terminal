-- 1. Создаем вспомогательную функцию для проверки админов без рекурсии
CREATE OR REPLACE FUNCTION is_admin()
RETURNS BOOLEAN 
LANGUAGE sql 
SECURITY DEFINER 
AS $$
  SELECT EXISTS (
    SELECT 1 FROM profiles
    WHERE id = auth.uid() AND role IN ('root', 'support')
  );
$$;

-- 2. Включаем RLS для всех таблиц
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE notes ENABLE ROW LEVEL SECURITY;
ALTER TABLE commands_history ENABLE ROW LEVEL SECURITY;

-- 3. Выдаем базовые права на таблицы для авторизованных пользователей
GRANT SELECT, UPDATE ON profiles TO authenticated;
GRANT ALL ON notes TO authenticated;
GRANT ALL ON commands_history TO authenticated;

-- ==========================================
-- 4. ПОЛИТИКИ ДЛЯ ПРОФИЛЕЙ (profiles)
-- ==========================================
DROP POLICY IF EXISTS "allow_select_for_authenticated" ON profiles;
DROP POLICY IF EXISTS "allow_update_own_profile" ON profiles;

-- Читать профили могут все авторизованные (нужно для whoami и проверки ролей)
CREATE POLICY "allow_select_for_authenticated" ON profiles
FOR SELECT USING (auth.role() = 'authenticated');

-- Менять свой профиль может только владелец
CREATE POLICY "allow_update_own_profile" ON profiles
FOR UPDATE USING (auth.uid() = id);

-- ==========================================
-- 5. ПОЛИТИКИ ДЛЯ ЗАМЕТОК (notes)
-- ==========================================
DROP POLICY IF EXISTS "notes_all_policy" ON notes;

-- Обычный юзер видит/редактирует только свои, root и support видят всё благодаря is_admin()
CREATE POLICY "notes_all_policy" ON notes
FOR ALL USING (
    created_by = auth.uid() OR is_admin()
);

-- ==========================================
-- 6. ПОЛИТИКИ ДЛЯ ИСТОРИИ КОМАНД (commands_history)
-- ==========================================
DROP POLICY IF EXISTS "history_all_policy" ON commands_history;

-- Юзер видит свою историю, администраторы видят всю
CREATE POLICY "history_all_policy" ON commands_history
FOR ALL USING (
    created_by = auth.uid() OR is_admin()
);
